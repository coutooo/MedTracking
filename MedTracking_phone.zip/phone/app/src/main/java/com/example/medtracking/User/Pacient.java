package com.example.medtracking.User;

public class Pacient {

    String nameAndcause,bed,inAndout;
    //int imageId;

    public Pacient(String nameAndcause, String bed, String inAndout) {  // int imageId
        this.nameAndcause = nameAndcause;
        this.bed = bed;
        this.inAndout = inAndout;
        //this.imageId = imageId;
    }
}
