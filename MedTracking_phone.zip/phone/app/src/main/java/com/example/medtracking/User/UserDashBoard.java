package com.example.medtracking.User;

import android.view.MenuItem;

import androidx.annotation.NonNull;


public class UserDashBoard {

    public void onBackPressed(){}

    public boolean onNavigationItemSelected(@NonNull MenuItem item){
        return true;
    }
}
